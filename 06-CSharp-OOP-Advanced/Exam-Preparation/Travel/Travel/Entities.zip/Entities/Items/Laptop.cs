﻿namespace Travel.Entities.Items
{
	public class Laptop : Item
	{
        private const int defautValue = 3000;

        public Laptop()
			: base(defautValue)

        {
		}
	}
}