﻿namespace Travel.Entities.Items
{
	public class Toothbrush : Item
	{
        private const int defautValue = 3;

        public Toothbrush()
			: base(defautValue)
		{
		}
	}
}