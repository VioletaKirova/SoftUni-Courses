﻿namespace Travel.Entities.Items
{
	public class Jewelery : Item
	{
        private const int defautValue = 300;

        public Jewelery()
			: base(defautValue)
		{
		}
	}
}