﻿namespace Travel.Entities.Items
{
	public class Colombian : Item
	{
        private const int defautValue = 50000;

		public Colombian()
			: base(defautValue)
		{
		}
	}
}