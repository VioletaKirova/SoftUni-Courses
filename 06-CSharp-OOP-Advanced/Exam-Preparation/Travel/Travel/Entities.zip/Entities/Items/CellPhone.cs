﻿namespace Travel.Entities.Items
{
    public class CellPhone : Item
    {
        private const int defautValue = 700;

        public CellPhone() 
            : base(defautValue)
        {
        }
    }
}
