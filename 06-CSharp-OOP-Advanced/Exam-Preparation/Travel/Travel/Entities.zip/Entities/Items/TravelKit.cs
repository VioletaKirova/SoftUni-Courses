﻿namespace Travel.Entities.Items
{
	public class TravelKit : Item
	{
        private const int defautValue = 30;

        public TravelKit()
			: base(defautValue)
		{
		}
	}
}