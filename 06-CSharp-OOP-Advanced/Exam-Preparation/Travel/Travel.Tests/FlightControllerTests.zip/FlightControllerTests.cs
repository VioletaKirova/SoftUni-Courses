// REMOVE any "using" statements, which start with "Travel." BEFORE SUBMITTING

namespace Travel.Tests
{
	using NUnit.Framework;
    //using Travel.Core.Controllers;
    //using Travel.Core.Controllers.Contracts;
    //using Travel.Entities;
    //using Travel.Entities.Airplanes;
    //using Travel.Entities.Airplanes.Contracts;
    //using Travel.Entities.Contracts;
    //using Travel.Entities.Items;
    //using Travel.Entities.Items.Contracts;

    [TestFixture]
    public class FlightControllerTests
    {
	    [Test]
	    public void TestOverbookedTripEjectsPassenger()
	    {
            IAirport airport = new Airport();
            IAirplane airplane = new LightAirplane();

            ITrip trip = new Trip("Sofia", "London", airplane);
            trip.Airplane.AddPassenger(new Passenger("Pesho"));
            trip.Airplane.AddPassenger(new Passenger("Gosho"));
            trip.Airplane.AddPassenger(new Passenger("Tosho"));
            trip.Airplane.AddPassenger(new Passenger("Kiro"));
            trip.Airplane.AddPassenger(new Passenger("Sasho"));
            trip.Airplane.AddPassenger(new Passenger("Misho"));
            airport.AddTrip(trip);

            IFlightController flightController = new FlightController(airport);
            string result = flightController.TakeOff();
            //"SofiaLondon1:\r\nOverbooked! Ejected Gosho\r\nConfiscated 0 bags ($0)\r\nSuccessfully transported 5 passengers from Sofia to London.\r\nConfiscated bags: 0 (0 items) => $0"

            bool actual = result.Contains("Overbooked! Ejected Gosho");
            bool expected = true;
            Assert.AreEqual(expected, actual);

            string actualId = trip.Id;
            string expectedId = "SofiaLondon1";
            Assert.AreEqual(expectedId, actualId);
        }

        [Test]
        public void TestSuccessfullyTransportsPassengers()
        {
            IAirport airport = new Airport();
            IAirplane airplane = new LightAirplane();

            ITrip trip = new Trip("Sofia", "London", airplane);
            trip.Airplane.AddPassenger(new Passenger("Pesho"));
            airport.AddTrip(trip);

            ITrip trip2 = new Trip("London", "Sofia", airplane);
            trip2.Airplane.AddPassenger(new Passenger("Gosho"));
            airport.AddTrip(trip2);

            IFlightController flightController = new FlightController(airport);
                      
            //SofiaLondon1:\r\nSuccessfully transported 2 passengers from Sofia to London.\r\nLondonSofia2:\r\nSuccessfully transported 2 passengers from London to Sofia.\r\nConfiscated bags: 0 (0 items) => $0
            string actual = flightController.TakeOff();
            string expected = "SofiaLondon1:\r\nSuccessfully transported 2 passengers from Sofia to London.\r\nLondonSofia2:\r\nSuccessfully transported 2 passengers from London to Sofia.\r\nConfiscated bags: 0 (0 items) => $0";
            Assert.AreEqual(expected, actual);
        }
    }
}
